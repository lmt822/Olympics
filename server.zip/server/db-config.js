// Private. Will not be included in submission
// Replace <Your Pennkey> and <Your Password>
module.exports = {
  host: "proj550.coavwyfb56wc.us-east-1.rds.amazonaws.com",
  user: "bigbrain",
  password: "550bigbrain",
  database: "OlympicDB",
  port: "1521"
};
